"use strict";

const base = {
  gender: "Female", SeniorCitizen: 0, Partner: "Yes", Dependents: "No",
  PhoneService: "Yes", MultipleLines: "No", InternetService: "Fiber optic",
  OnlineSecurity: "No", OnlineBackup: "No", DeviceProtection: "No",
  TechSupport: "No", StreamingTV: "Yes", StreamingMovies: "Yes",
  Contract: "Month-to-month", PaperlessBilling: "Yes",
  PaymentMethod: "Electronic check", tenure: 4, MonthlyCharges: 98,
  TotalCharges: 392,
};
const demoChanges = [
  { tenure: 2, MonthlyCharges: 115, TotalCharges: 230 },
  { tenure: 8, MonthlyCharges: 110, TotalCharges: 880, SeniorCitizen: 1 },
  { tenure: 14, MonthlyCharges: 105, TotalCharges: 1470, PaymentMethod: "Mailed check" },
  { tenure: 31, MonthlyCharges: 90, TotalCharges: 2790, Contract: "One year" },
  { tenure: 56, MonthlyCharges: 84, TotalCharges: 4704, Contract: "Two year" },
  { tenure: 6, MonthlyCharges: 127, TotalCharges: 762, Partner: "No" },
  { tenure: 20, MonthlyCharges: 78, TotalCharges: 1560, InternetService: "DSL" },
  { tenure: 1, MonthlyCharges: 120, TotalCharges: 120, Dependents: "Yes" },
];
const demo = demoChanges.map((change, index) => ({
  ...base, ...change, customerID: `DEMO-${String(index + 1).padStart(2, "0")}`,
  contact_eligible: index !== 2,
  days_since_last_contact: [90, 5, 120, 40, 2, 20, 60, 3][index],
}));
const required = [...Object.keys(base), "customerID"];
const state = { records: [], source: "", result: null, scenario: null };
const $ = (id) => document.getElementById(id);
const money = (value) => Number(value).toLocaleString(undefined, { maximumFractionDigits: 2, minimumFractionDigits: 2 });
const pct = (value) => `${(Number(value) * 100).toFixed(1)}%`;

function setStatus(message, kind = "idle") {
  const host = $("data-state");
  host.dataset.state = kind;
  host.querySelector(".status-symbol").textContent = kind === "ready" ? "✓" : kind === "error" ? "!" : "○";
  host.querySelector("span:last-child").textContent = message;
}

function loadRecords(records, source) {
  const ids = records.map((record) => record.customerID);
  if (ids.length < 1 || ids.length > 1000) throw new Error("Use a CSV with 1 to 1,000 customers.");
  if (new Set(ids).size !== ids.length) throw new Error("customerID values must be unique. Remove duplicate rows and try again.");
  state.records = records;
  state.source = source;
  state.result = null;
  $("review-content").hidden = true;
  $("empty-review").hidden = false;
  $("preview").disabled = false;
  $("model-state").textContent = `${records.length} customers ready · local API`;
  setStatus(`${records.length} ${source === "fictional_demo" ? "fictional" : "CSV"} customers loaded. Set your assumptions and preview a draft.`, "ready");
}

function invalidateDraft() {
  if (!state.result) return;
  state.result = null;
  state.scenario = null;
  $("review-content").hidden = true;
  $("empty-review").hidden = false;
  $("empty-review").querySelector("h3").textContent = "Assumptions changed";
  $("empty-review").querySelector("p").textContent = "Preview again to calculate a draft with the current settings.";
  $("model-state").textContent = "Assumptions changed · preview again.";
}

function parseCSV(text) {
  const rows = [];
  let row = [], cell = "", quoted = false;
  text = text.replace(/^\uFEFF/, "");
  for (let index = 0; index < text.length; index++) {
    const char = text[index];
    if (char === '"') {
      if (quoted && text[index + 1] === '"') { cell += '"'; index++; }
      else quoted = !quoted;
    } else if (char === "," && !quoted) { row.push(cell); cell = ""; }
    else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[index + 1] === "\n") index++;
      row.push(cell); cell = "";
      if (row.some((part) => part.trim() !== "")) rows.push(row);
      row = [];
    } else cell += char;
  }
  if (quoted) throw new Error("The CSV has an unclosed quoted field.");
  row.push(cell);
  if (row.some((part) => part.trim() !== "")) rows.push(row);
  if (rows.length < 2) throw new Error("The CSV needs a header and at least one customer row.");
  const headers = rows.shift().map((item) => item.trim());
  if (new Set(headers).size !== headers.length) throw new Error("The CSV contains duplicate column names.");
  const missing = required.filter((name) => !headers.includes(name));
  if (missing.length) throw new Error(`Missing required columns: ${missing.join(", ")}.`);
  const numeric = new Set(["SeniorCitizen", "tenure", "MonthlyCharges", "TotalCharges"]);
  return rows.map((cells, index) => {
    if (cells.length !== headers.length) throw new Error(`CSV row ${index + 2} has ${cells.length} fields; expected ${headers.length}.`);
    const record = {};
    required.forEach((name) => {
      const value = cells[headers.indexOf(name)].trim();
      if (numeric.has(name) && value === "" && name !== "TotalCharges") {
        throw new Error(`CSV row ${index + 2}: ${name} is required.`);
      }
      record[name] = numeric.has(name) ? (value === "" && name === "TotalCharges" ? null : Number(value)) : value;
      if (numeric.has(name) && record[name] !== null && !Number.isFinite(record[name])) {
        throw new Error(`CSV row ${index + 2}: ${name} must be numeric.`);
      }
    });
    if (headers.includes("contact_eligible")) {
      const raw = cells[headers.indexOf("contact_eligible")].trim().toLowerCase();
      if (!["", "true", "false", "yes", "no", "1", "0"].includes(raw)) {
        throw new Error(`CSV row ${index + 2}: contact_eligible must be true or false.`);
      }
      record.contact_eligible = raw === "" ? null : ["true", "yes", "1"].includes(raw);
    }
    if (headers.includes("days_since_last_contact")) {
      const raw = cells[headers.indexOf("days_since_last_contact")].trim();
      const days = raw === "" ? null : Number(raw);
      if (days !== null && (!Number.isInteger(days) || days < 0)) {
        throw new Error(`CSV row ${index + 2}: days_since_last_contact must be a non-negative whole number.`);
      }
      record.days_since_last_contact = days;
    }
    return record;
  });
}

function currentScenario() {
  const form = $("scenario-form");
  if (!form.reportValidity()) return null;
  return {
    budget_fraction: Number($("capacity").value) / 100,
    max_total_cost: $("total-cost-cap").value === "" ? null : Number($("total-cost-cap").value),
    cooldown_days: Number($("cooldown-days").value),
    scenario: {
      name: "analyst_scenario",
      save_rate: Number($("save-rate").value) / 100,
      gross_margin_rate: Number($("margin-rate").value) / 100,
      contact_offer_cost: Number($("contact-cost").value),
      horizon_months: Number($("horizon").value),
    },
  };
}

function metric(label, value, detail) {
  const card = document.createElement("div");
  card.className = "metric";
  const title = document.createElement("span"), number = document.createElement("strong"), caption = document.createElement("small");
  title.textContent = label; number.textContent = value; caption.textContent = detail;
  card.append(title, number, caption);
  return card;
}

function render(result, config) {
  $("empty-review").hidden = true;
  $("review-content").hidden = false;
  $("assumption-warning").textContent = result.assumption_warning;
  const selected = result.selected;
  const total = result.summary.simulated_total_expected_value;
  const metrics = $("metric-grid");
  metrics.replaceChildren(
    metric("Customers scored", String(result.summary.input_customers), state.source === "fictional_demo" ? "Fictional demo" : "Uploaded CSV"),
    metric("Contacts in draft", String(result.summary.selected_customers), `Hard cap: ${result.summary.contact_capacity} (${pct(config.budget_fraction)})`),
    metric("Scenario value", money(total), "Illustrative monetary units"),
    metric("Assumed contact spend", money(result.summary.assumed_contact_spend), config.max_total_cost === null ? "No extra money cap" : `Cap: ${money(config.max_total_cost)}`),
    metric("Not excluded", String(result.summary.input_customers - (result.summary.reason_counts.not_eligible || 0) - (result.summary.reason_counts.cooldown_active || 0) - (result.summary.reason_counts.missing_contact_history || 0)), `Flags: ${result.summary.eligibility_flags_supplied}/${result.summary.input_customers} · history: ${result.summary.contact_history_supplied}/${result.summary.input_customers}`),
    metric("Model version", result.model_version, result.model_sha256 ? `Bundle ${result.model_sha256.slice(0, 12)}` : "Static IBM-style risk model")
  );
  $("scenario-total").textContent = money(total);
  $("comparison-note").textContent = `${selected.length} contacts with positive scenario value. This is a calculation under your assumptions, not measured uplift.`;
  const sensitivity = $("sensitivity-grid");
  sensitivity.replaceChildren();
  result.sensitivity.forEach((item) => {
    const card = document.createElement("div");
    card.className = `sensitivity-card${item.label === "current" ? " current" : ""}`;
    const label = document.createElement("span"), value = document.createElement("strong"), detail = document.createElement("small");
    label.textContent = `${item.label} · ${pct(item.assumed_save_rate)}`;
    value.textContent = money(item.simulated_total_expected_value);
    detail.textContent = `${item.selected_customers} contacts · scenario units`;
    card.append(label, value, detail);
    sensitivity.append(card);
  });
  $("table-caption").textContent = `${selected.length} selected out of ${result.summary.input_customers} customers`;
  const body = $("selected-body");
  body.replaceChildren();
  selected.forEach((item) => {
    const row = document.createElement("tr");
    [item.customer_id, pct(item.risk_30d), money(item.monthly_charges), money(item.simulated_expected_value),
      item.break_even_save_rate !== null && Number.isFinite(item.break_even_save_rate) ? pct(item.break_even_save_rate) : "Not reachable"].forEach((value) => {
      const cell = document.createElement("td"); cell.textContent = value; row.append(cell);
    });
    body.append(row);
  });
  if (!selected.length) {
    const row = document.createElement("tr"), cell = document.createElement("td");
    cell.colSpan = 5;
    const excluded = (result.summary.reason_counts.not_eligible || 0)
      + (result.summary.reason_counts.cooldown_active || 0)
      + (result.summary.reason_counts.missing_contact_history || 0);
    cell.textContent = result.summary.contact_capacity === 0
      ? "The hard contact cap permits zero contacts in this snapshot. Increase the capacity or load more customers."
      : excluded === result.summary.input_customers
        ? "All customers are excluded by the supplied eligibility or cooldown rules."
      : result.summary.reason_counts.cost_cap_reached
        ? "The total cost cap permits zero contacts at this assumed cost."
        : "No customer has positive value under these assumptions. The draft recommends no contact.";
    row.append(cell); body.append(row);
  }
  const skipped = result.ranked_candidates.filter((item) => !item.selected);
  $("skip-count").textContent = `(${skipped.length})`;
  const skippedBody = $("skipped-body");
  skippedBody.replaceChildren();
  skipped.slice(0, 20).forEach((item) => {
    const row = document.createElement("tr");
    const reason = {
      non_positive_value: "No positive value under assumptions",
      contact_cap_reached: "Contact cap reached",
      cost_cap_reached: "Total cost cap reached",
      not_eligible: "Marked ineligible in snapshot",
      cooldown_active: "Within contact cooldown",
      missing_contact_history: "Missing history for cooldown rule",
    }[item.reason] || item.reason;
    [item.customer_id, money(item.simulated_expected_value), reason].forEach((value) => {
      const cell = document.createElement("td"); cell.textContent = value; row.append(cell);
    });
    skippedBody.append(row);
  });
  $("review").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function preview(event) {
  event.preventDefault();
  const config = currentScenario();
  if (!config || !state.records.length) return;
  $("preview").disabled = true;
  $("model-state").textContent = "Scoring with the local model…";
  try {
    const response = await fetch("/v1/campaigns/preview", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ records: state.records, ...config }),
    });
    const payload = await response.json();
    if (!response.ok) {
      const detail = Array.isArray(payload.detail) ? payload.detail.slice(0, 3).map((item) => `${item.loc?.join(".")}: ${item.msg}`).join("; ") : payload.detail;
      throw new Error(detail || `Local API returned ${response.status}.`);
    }
    state.result = payload;
    state.scenario = config;
    render(payload, config);
    $("model-state").textContent = "Draft ready for human review.";
  } catch (error) {
    $("model-state").textContent = "Preview unavailable.";
    setStatus(`Could not score the snapshot: ${error.message}`, "error");
    $("data").scrollIntoView({ behavior: "smooth" });
  } finally { $("preview").disabled = false; }
}

function download(filename, contents, type) {
  const url = URL.createObjectURL(new Blob([contents], { type }));
  const link = document.createElement("a"); link.href = url; link.download = filename;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function csvCell(value) { return `"${String(value ?? "").replaceAll('"', '""')}"`; }
function exportCSV() {
  if (!state.result) return;
  const keys = ["customer_id", "risk_30d", "monthly_charges", "simulated_expected_value", "break_even_save_rate", "scenario"];
  const rows = [keys.join(","), ...state.result.selected.map((item) => keys.map((key) => csvCell(item[key])).join(","))];
  download("retention-draft-selected.csv", rows.join("\r\n"), "text/csv;charset=utf-8");
}
function exportAudit() {
  if (!state.result) return;
  const keys = ["customer_id", "rank", "selected", "reason", "risk_30d", "monthly_charges", "simulated_expected_value", "break_even_save_rate", "scenario"];
  const rows = [keys.join(","), ...state.result.ranked_candidates.map((item) => keys.map((key) => csvCell(item[key])).join(","))];
  download("retention-decision-audit.csv", rows.join("\r\n"), "text/csv;charset=utf-8");
}
async function exportPacket() {
  if (!state.result) return;
  const bytes = new TextEncoder().encode(JSON.stringify(state.records));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const inputSha256 = [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  const packet = {
    packet_version: 1, generated_at: new Date().toISOString(), source: state.source,
    input_sha256: inputSha256, input_customers: state.records.length,
    input_records: state.records,
    model_version: state.result.model_version, model_sha256: state.result.model_sha256,
    policy_type: state.result.policy_type,
    evidence_type: state.result.evidence_type, assumptions: state.scenario,
    score_scope_note: state.result.score_scope_note,
    assumption_warning: state.result.assumption_warning,
    summary: state.result.summary, sensitivity: state.result.sensitivity,
    ranked_candidates: state.result.ranked_candidates, selected: state.result.selected,
    limitation: "Risk score on a static sample; offer response, costs and value are assumed. No measured causal effect or launch recommendation.",
  };
  download("retention-draft-evidence.json", JSON.stringify(packet, null, 2), "application/json");
}

$("load-demo").addEventListener("click", () => { loadRecords(demo, "fictional_demo"); $("design").scrollIntoView({ behavior: "smooth" }); });
$("demo-secondary").addEventListener("click", () => { loadRecords(demo, "fictional_demo"); $("design").scrollIntoView({ behavior: "smooth" }); });
$("csv-file").addEventListener("change", async (event) => {
  const file = event.target.files?.[0]; if (!file) return;
  try {
    if (file.size > 2_000_000) throw new Error("The CSV must be 2 MB or smaller.");
    loadRecords(parseCSV(await file.text()), "uploaded_csv");
    $("design").scrollIntoView({ behavior: "smooth" });
  } catch (error) { setStatus(error.message, "error"); }
  event.target.value = "";
});
$("capacity").addEventListener("input", () => { $("capacity-readout").textContent = `${$("capacity").value}%`; });
$("scenario-form").addEventListener("input", invalidateDraft);
$("scenario-form").addEventListener("submit", preview);
$("export-csv").addEventListener("click", exportCSV);
$("export-audit").addEventListener("click", exportAudit);
$("export-json").addEventListener("click", exportPacket);
